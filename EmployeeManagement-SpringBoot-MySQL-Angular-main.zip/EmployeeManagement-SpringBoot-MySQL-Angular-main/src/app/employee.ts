export interface Employee{
    id: number;
    name: string;
    phone: string;
    employeeCode: string;
    email: string;
    jobTitle: string;
    imageUrl: string;
}